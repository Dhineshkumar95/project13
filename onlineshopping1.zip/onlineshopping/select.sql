create table T_XBBNHMH_ORDERLIST
(C_Phone_No varchar(10),Product_ID int,Delivery_address varchar(40),price int); 


insert into T_XBBNHMH_ORDERLIST values('9789174069',1001,'18,vasu st,guindy',200);
insert into T_XBBNHMH_ORDERLIST values('9789174068',1002,'18,vas st,saidapet',4000);

select * from T_XBBNHMH_ORDERLIST;

drop table T_XBBNHMH_ORDERLIST;

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

create table T_XBBNHMH_ADMINDETAILS(Admin_ID varchar(20), Password_Admin varchar(8));
select * from T_XBBNHMH_ADMINDETAILS;
insert into T_XBBNHMH_ADMINDETAILS values('412413','password');
drop table T_XBBNHMH_ADMINDETAILS;

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

create table T_XBBNHMH_USERDETAILS(C_PHONE_NO varchar(10),C_Name varchar(20),password_user varchar(8));
select * from T_XBBNHMH_USERDETAILS;
insert into T_XBBNHMH_USERDETAILS values('9789174069','Ram','pwd12345');
insert into T_XBBNHMH_USERDETAILS values('9789174068','Mohan','pwd67890');
insert into T_XBBNHMH_USERDETAILS values('9789174067','Murali','pwd45678');
drop table T_XBBNHMH_USERDETAILS;
delete from T_XBBNHMH_USERDETAILS where password_user='123';

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

create table T_XBBNHMH_VENDORDETAILS(V_PHONE_NO varchar(10),V_Name varchar(20), password_vendor varchar(8));
select * from T_XBBNHMH_VENDORDETAILS;
insert into T_XBBNHMH_VENDORDETAILS values('9790774265','gopal','gopal123');
insert into T_XBBNHMH_VENDORDETAILS values('9790774265','arun','arun1234');
insert into T_XBBNHMH_VENDORDETAILS values('9790774265','star','star1234');
drop table T_XBBNHMH_VENDORDETAILS;

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

create table T_XBBNHMH_PRODUCTDETAILS(product_id int, V_name varchar(20), product_name varchar(20));
alter table T_XBBNHMH_PRODUCTDETAILS add price int;
select * from T_XBBNHMH_PRODUCTDETAILS;
delete from T_XBBNHMH_PRODUCTDETAILS;
insert into T_XBBNHMH_PRODUCTDETAILS values(1001,'gopal','pendrive',200);
insert into T_XBBNHMH_PRODUCTDETAILS values(1002,'arun','mobile',10000);
insert into T_XBBNHMH_PRODUCTDETAILS values(1003,'star','harddisk',4000);
drop table T_XBBNHMH_PRODUCTDETAILS;

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

