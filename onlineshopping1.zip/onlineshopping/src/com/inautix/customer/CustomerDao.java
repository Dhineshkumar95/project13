package com.inautix.customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;





import com.inautix.order.ConnectionManager;

public class CustomerDao 

{

	public void put_user_details(String C_phone_no,String C_name,String pwd1)
	{
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String insertQuery = "Insert into T_XBBNHMH_USERDETAILS values(?,?,?)";
		try {
			 stmt=conn.prepareStatement(insertQuery);
			 stmt.setString(1,C_phone_no);
			 stmt.setString(2,C_name);
			 stmt.setString(3,pwd1);
			 
			 stmt.executeUpdate();
			 
			
			 } catch (SQLException e) 
			 {e.printStackTrace();}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	public void delete_order(String C_phone_no,int p_id1)
	{
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String insertQuery = "delete from T_XBBNHMH_ORDERLIST where Product_ID=? and C_Phone_No=?";
		try {
			 stmt=conn.prepareStatement(insertQuery);
			 stmt.setInt(1,p_id1);
			 stmt.setString(2,C_phone_no);
			 stmt.executeUpdate();
			 
			
			 } catch (SQLException e) 
			 {e.printStackTrace();}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
	
	public void make_order(String C_phone_no,int p_id,String add,int amnt)
	{
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String insertQuery = "Insert into T_XBBNHMH_ORDERLIST values(?,?,?,?)";
		try {
			 stmt=conn.prepareStatement(insertQuery);
			 stmt.setString(1,C_phone_no);
			 stmt.setInt(2,p_id);
			 stmt.setString(3,add);
			 stmt.setInt(4,amnt);
			 
			 stmt.executeUpdate();
			 
			
			 } catch (SQLException e) 
			 {e.printStackTrace();}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

	public boolean isValid(String username,String password) throws SQLException

    {
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           
                  stmt = con.prepareStatement("select * from T_XBBNHMH_USERDETAILS where C_PHONE_NO = ? AND password_user= ?");
                  stmt.setString(1, username);
                  stmt.setString(2, password);
           
           boolean isValid = false;
           ResultSet rs = null;
           
           rs = stmt.executeQuery();
                  
           while(rs.next())
           {
                  isValid = true;
           }
           con.close();
           return isValid;
           
    }
	
	public boolean isThere(String username) throws SQLException
    {
		boolean isThere=true;
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           ResultSet resultset = null;
                  stmt = con.prepareStatement("select * from T_XBBNHMH_USERDETAILS where C_PHONE_NO = ?");
                  stmt.setString(1, username);
                  resultset = stmt.executeQuery();
                  String s="";
                  while(resultset.next())
                   s = resultset.getString(1);
                  if(s.equals(username))
                  {
                	  
                	  isThere=true;
                  }
                  else
                  {
                	  
                	  isThere=false;
                  }
           
           return isThere;
                 
    }
	
	public static int getPrice(int p_id) throws SQLException

    {
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           
                  stmt = con.prepareStatement("select * from T_XBBNHMH_PRODUCTDETAILS where product_id=?");
                  stmt.setInt(1, p_id);
                  
           
           
           ResultSet rs = null;
           
           rs = stmt.executeQuery();
           int price=0;
		while(rs.next())
           {price=rs.getInt(4);}
           
           return price;
           
    }

}
