package com.inautix.customer;

import java.sql.SQLException;
import java.util.Scanner;

import com.inautix.admin.AdminDao;

public class CustomerApp {
	public static void main(String args[]) throws SQLException
	{
		CustomerDao customerDao = new CustomerDao();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter phone number(user id)");
		String C_phone_no=sc.nextLine();
		
		boolean b = customerDao.isThere(C_phone_no);
		if(b==false)
		{
		System.out.println("you are not an existing user\nenter your(customer) details\nEnter you name");
		String C_name=sc.nextLine();
		System.out.println("Enter your new password");
		String pwd1=sc.nextLine();
		customerDao.put_user_details(C_phone_no, C_name,pwd1);
		}
		else if(b==true){
			System.out.println("enter password");
			String p=sc.nextLine();
			boolean isValid = customerDao.isValid(C_phone_no,p);
	        if(isValid == true)
	        {
	        	System.out.println("logged in successfully");
	        	System.out.println("1.make order\n2.delete order");
	    		int choice=sc.nextInt();
	    		switch(choice)
	    		{
	    		
	    		case 1:
	    		{
	    			//customer adds order
	    			System.out.println("enter product id");
	    			int p_id=sc.nextInt();
	    			sc.nextLine();
	    			System.out.println("enter delivery address");
	    			String add=sc.nextLine();
	    			int amnt=customerDao.getPrice(p_id);
	    			customerDao.make_order(C_phone_no,p_id,add,amnt);
	    			System.out.println("order made");
	    			break;
	    		}
	    		case 2:
	    		{
	    			//customer deletes order
	    			System.out.println("enter product id");
	    			int p_id1=sc.nextInt();
	    			customerDao.delete_order(C_phone_no,p_id1);
	    			System.out.println("order removed");
	    			break;
	    		}
	    		}
	        }
	        else{System.out.println("wrong userid/password");}
		}
		
	}
}
