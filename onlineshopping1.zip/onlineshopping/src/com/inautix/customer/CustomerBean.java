package com.inautix.customer;

public class CustomerBean {
	private String c_phone_no,c_name,delivery_address,password_user;

	public String getC_phone_no() {
		return c_phone_no;
	}

	public void setC_phone_no(String c_phone_no) {
		this.c_phone_no = c_phone_no;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getDelivery_address() {
		return delivery_address;
	}

	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}

	public String getPassword_user() {
		return password_user;
	}

	public void setPassword_user(String password_user) {
		this.password_user = password_user;
	}
	
}
