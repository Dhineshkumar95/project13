package com.inautix.product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.inautix.order.ConnectionManager;



public class ProductDao {
	
	
	
	
	public List getProduct()
	{
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<ProductBean> Product = null;
			ResultSet resultset = null;
			String searchQuery = "SELECT *  from T_XBBNHMH_Productdetails";
			try {
				 stmt=conn.prepareStatement(searchQuery);
				 resultset=stmt.executeQuery();
				 Product = new ArrayList<ProductBean>();
				 
				while(resultset.next()) 
				 {
					ProductBean productBean = new ProductBean();
					productBean.setProduct_id(resultset.getInt(1));
					productBean.setV_name(resultset.getString(2));
					productBean.setProduct_name(resultset.getString(3));
					productBean.setPrice(resultset.getInt(4));
					Product.add(productBean);
				  }
				
				 } catch (SQLException e) 
				 {e.printStackTrace();}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return Product;
	}	

	public List getProductSearch(String P_name)
	{
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<ProductBean> Product = null;
			ResultSet resultset = null;
			
			try {
				 stmt=conn.prepareStatement("SELECT *  from T_XBBNHMH_Productdetails WHERE product_name like ?");
				
                 stmt.setString(1, "%"+P_name+"%");
				 resultset=stmt.executeQuery();
				 Product = new ArrayList<ProductBean>();
				 
				while(resultset.next()) 
				 {
					ProductBean productBean = new ProductBean();
					productBean.setProduct_id(resultset.getInt(1));
					productBean.setV_name(resultset.getString(2));
					productBean.setProduct_name(resultset.getString(3));
					productBean.setPrice(resultset.getInt(4));
					Product.add(productBean);
				  }
				
				 } catch (SQLException e) 
				 {e.printStackTrace();}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return Product;
	}	

	public boolean isPresent(int pid) throws SQLException 

    {
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           
                  stmt = con.prepareStatement("select * from T_XBBNHMH_PRODUCTDETAILS where product_id=?");
                  stmt.setInt(1, pid);
                 
           
           boolean isValid = false;
           ResultSet rs = null;
           
           rs = stmt.executeQuery();
                  
           while(rs.next())
           {
                  isValid = true;
           }
           con.close();
           return isValid;
           
    }

}
