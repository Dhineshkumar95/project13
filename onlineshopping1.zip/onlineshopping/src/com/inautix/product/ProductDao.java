package com.inautix.product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.inautix.order.ConnectionManager;



public class ProductDao {
	
	
	
	
	public List getProduct()
	{
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<ProductBean> Product = null;
			ResultSet resultset = null;
			String searchQuery = "SELECT *  from T_XBBNHMH_Productdetails";
			try {
				 stmt=conn.prepareStatement(searchQuery);
				 resultset=stmt.executeQuery();
				 Product = new ArrayList<ProductBean>();
				 
				while(resultset.next()) 
				 {
					ProductBean productBean = new ProductBean();
					productBean.setProduct_id(resultset.getInt(1));
					productBean.setV_name(resultset.getString(2));
					productBean.setProduct_name(resultset.getString(3));
					productBean.setPrice(resultset.getInt(4));
					Product.add(productBean);
				  }
				
				 } catch (SQLException e) 
				 {e.printStackTrace();}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return Product;
	}	

	

}
