package com.inautix.product;

import java.util.Iterator;
import java.util.List;


public class ProductApp {
	public static void main(String[] args) {
		
		ProductDao productDao = new ProductDao();
	
		
		List<ProductBean> Product = productDao.getProduct();
		Iterator<ProductBean> itr =  Product.iterator();
		while(itr.hasNext())
		{
			ProductBean productBean = itr.next();
			System.out.println(productBean.getProduct_id()+"\t\t"+productBean.getV_name()+"\t\t"+productBean.getProduct_name()+"\t\t"+productBean.getPrice());
		}
		
	 
		
	 
		
		
		
	}
}
