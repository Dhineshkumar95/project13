package com.inautix.product;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class ProductApp {
	public static void main(String[] args) throws SQLException {
		
		ProductDao productDao = new ProductDao();
	
		Scanner sc=new Scanner(System.in);
		List<ProductBean> Product = productDao.getProduct();
		Iterator<ProductBean> itr =  Product.iterator();
		while(itr.hasNext())
		{
			ProductBean productBean = itr.next();
			System.out.println(productBean.getProduct_id()+"\t\t"+productBean.getV_name()+"\t\t"+productBean.getProduct_name()+"\t\t"+productBean.getPrice());
		}
		
		String s=sc.nextLine();
		
		List<ProductBean> Product1 = productDao.getProductSearch(s);
		
		Iterator<ProductBean> itr1 =  Product1.iterator();
		while(itr1.hasNext())
		{
			ProductBean productBean = itr1.next();
			System.out.println(productBean.getProduct_id()+"\t\t"+productBean.getV_name()+"\t\t"+productBean.getProduct_name()+"\t\t"+productBean.getPrice());
		}
		
		int pid=sc.nextInt();
		if(productDao.isPresent(pid))
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");
		}
		
	}
}
