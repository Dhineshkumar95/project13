package com.inautix.servletcontroller;


	
	import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

	import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.customer.*;

	

	public class Customer_Login1_servlet extends HttpServlet {
	                private static final long serialVersionUID = 1L;

	                public Customer_Login1_servlet() {
	                                super();
	                                // TODO Auto-generated constructor stub
	                }

	                protected void doPost(HttpServletRequest request, HttpServletResponse response)
	                                                throws ServletException, IOException {
	                                PrintWriter out = response.getWriter();
	                                String userId = request.getParameter("uname");
	                                String passWord = request.getParameter("psw");
	                
	                                CustomerDao customerdao=new CustomerDao();
	                                
	                                
	                                try {
										if(customerdao.isValid(userId,passWord)) {
											Cookie ck2=new Cookie("uname",userId); 
								          
								            response.addCookie(ck2); 
								            
								            RequestDispatcher requestDispatcher = request.getRequestDispatcher("Customer.html");
										    requestDispatcher.forward(request, response);
										                /*
										                * out.println("<script type=\"text/javascript\">"); out.println(
										                * "alert('Successful Login, Farmer!!!');");
										                * out.println("location='FarmerDashboard.jsp?user=" + userName +
										                * "';"); out.println("</script>");
										                */
										} else if(customerdao.isThere(userId)) 
										{
											out.println("<script type=\"text/javascript\">");
							                out.println("alert('Wrong password');");
							                out.println("location='Customer_Login1.html';");
							                out.println("</script>");
										}	
										else
										{
										                /*
										                * out.print("Sorry UserName or Password Error!"); RequestDispatcher
										                * requestDispatcher = request.getRequestDispatcher("/Login.jsp");
										                * requestDispatcher.include(request, response);
										                */
										                out.println("<script type=\"text/javascript\">");
										                out.println("alert('No such Account Found');");
										                out.println("location='Customer_Login1.html';");
										                out.println("</script>");
										}
										
									} catch (SQLException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
	                                // doPost(request, response);
	                }


	}




