package com.inautix.servletcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.customer.CustomerDao;

public class Customer_signup_servlet extends HttpServlet{
	 private static final long serialVersionUID = 1L;

	    public Customer_signup_servlet() {
	                    super();
	                    // TODO Auto-generated constructor stub
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	                                    throws ServletException, IOException {
	                    PrintWriter out = response.getWriter();
	                    String userId = request.getParameter("C_phone_no");
	                    String name = request.getParameter("C_name");
	                    String passWord =request.getParameter("pwd1");
	                    CustomerDao customerdao=new CustomerDao();
	                    customerdao.put_user_details(userId,name,passWord);
		                out.println("signed-up successfully");
	                    RequestDispatcher requestDispatcher = request.getRequestDispatcher("Customer_Login1.html");
						requestDispatcher.include(request, response);
						
	    }


}
