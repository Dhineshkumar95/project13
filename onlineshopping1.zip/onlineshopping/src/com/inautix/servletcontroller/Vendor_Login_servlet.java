package com.inautix.servletcontroller;


	
	import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

	import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.vendor.VendorDao;



	

	public class Vendor_Login_servlet extends HttpServlet {
	                private static final long serialVersionUID = 1L;

	                public Vendor_Login_servlet() {
	                                super();
	                        
	                }

	                protected void doPost(HttpServletRequest request, HttpServletResponse response)
	                                                throws ServletException, IOException {
	                                PrintWriter out = response.getWriter();
	                                String userId = request.getParameter("uname");
	                                String passWord = request.getParameter("psw");
	                
	                                VendorDao vendordao=new VendorDao();
	                                
	                                
	                                try {
										if(vendordao.isValid(userId,passWord)) {
											Cookie ck5=new Cookie("uname",userId); 
								           
								            response.addCookie(ck5); 
								            
								            RequestDispatcher requestDispatcher = request.getRequestDispatcher("Vendor.html");
										    requestDispatcher.forward(request, response);
										              
										} else if(vendordao.isThere(userId)) 
										{
											out.println("<script type=\"text/javascript\">");
							                out.println("alert('Wrong password');");
							                out.println("location='Vendor_Login.html';");
							                out.println("</script>");
										}	
										else
										{
										                out.println("<script type=\"text/javascript\">");
										                out.println("alert('No such Account Found');");
										                out.println("location='Vendor_Login.html';");
										                out.println("</script>");
										}
										
									} catch (SQLException e) {
									
										e.printStackTrace();
									}
	                               
	                }


	}




