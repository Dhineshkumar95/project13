package com.inautix.servletcontroller;




	import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

	import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.admin.AdminDao;


	

	public class Admin_Login1_servlet extends HttpServlet {
	                private static final long serialVersionUID = 1L;

	                public Admin_Login1_servlet() {
	                                super();
	                             
	                }

	                protected void doPost(HttpServletRequest request, HttpServletResponse response)
	                                                throws ServletException, IOException {
	                                PrintWriter out = response.getWriter();
	                                String userId = request.getParameter("uname");
	                                String passWord = request.getParameter("psw");
	                
	                                AdminDao adminDao=new AdminDao();
	                        		
	                                
	                                try {
										if(adminDao.isValid(userId,passWord)) {
											Cookie ck=new Cookie("uname",userId); 
								            
								            response.addCookie(ck); 
								            
								            RequestDispatcher requestDispatcher = request.getRequestDispatcher("Admin.html");
										    requestDispatcher.forward(request, response);
										               
										} 
										else
										{
										                out.println("<script type=\"text/javascript\">");
										                out.println("alert('No such Account Found');");
										                out.println("location='Admin_Login1.html';");
										                out.println("</script>");
										}
										
									} catch (SQLException e) {
										
										e.printStackTrace();
									}
	         
	                }


	}




