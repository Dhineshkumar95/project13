package com.inautix.servletcontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.admin.AdminDao;

public class Delete_Product_Servlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

    public Delete_Product_Servlet() {
                    super();
                    // TODO Auto-generated constructor stub
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                    throws ServletException, IOException {
                    PrintWriter out = response.getWriter();
                    Cookie ck[]=request.getCookies();
                    int k=0;
            		if(ck!=null)
            		{ 
            			for(int i=0;i<ck.length;i++)
            			{
            				String name=ck[i].getName();  
            				if(name.equals("uname"))
            				{
            					k=1;
            				}
            			}
            		}
            		if(k==1)
                    {
                    String pId=request.getParameter("ID");
                    int pID=Integer.parseInt(pId);
                    AdminDao admindao=new AdminDao();
                    admindao.delete_product_detail(pID);;
                    
                    
							out.println("<script type=\"text/javascript\">");
			                out.println("alert('Product Deleted');");
			                out.println("location='add_delete_product.html';");
			                out.println("</script>");
						
                    }
                    else{
                    	out.println("session expired");
            			request.getRequestDispatcher("Admin_Login1.html").include(request, response);  
                    }
				
                    
    }

}
