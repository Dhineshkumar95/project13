package com.inautix.servletcontroller;


	

	import java.io.IOException;
import java.io.PrintWriter;

import java.util.Iterator;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.inautix.product.ProductBean;
import com.inautix.product.ProductDao;

	public class Productservlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    public Productservlet() {
	                    super();
	                    // TODO Auto-generated constructor stub
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	                                    throws ServletException, IOException {
	                    PrintWriter out = response.getWriter();
	                    
	                    ProductDao productDao=new ProductDao();
	                    out.print("<head><link rel='StyleSheet' href='CSS/Product.css' type='text/css' /></head>");
	                    List<ProductBean> Product = productDao.getProduct();
	            		Iterator<ProductBean> itr =  Product.iterator();
	            		out.print("<h1><center>PRODUCT LIST</center></h1><table> <tr><th>Product ID</th><th>Product Name</th><th>Vendor Name</th><th>Price(Rs.)</th></tr>");
	            		while(itr.hasNext())
	            		{
	            			ProductBean productBean = itr.next();
	            			out.print("<tr><td>"+productBean.getProduct_id()+"</td><td>"+productBean.getV_name()+"</td><td>"+productBean.getProduct_name()+"</td><td>"+productBean.getPrice()+"</td></tr>");
	         
	            		}
	            		out.print("</table>");
	                                  
	    }


	}






