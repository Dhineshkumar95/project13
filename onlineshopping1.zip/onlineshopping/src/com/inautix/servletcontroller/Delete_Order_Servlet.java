package com.inautix.servletcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.customer.CustomerDao;

public class Delete_Order_Servlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

    public Delete_Order_Servlet() {
                    super();
                    // TODO Auto-generated constructor stub
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                    throws ServletException, IOException {
                    PrintWriter out = response.getWriter();
                    Cookie ck[]=request.getCookies();
                   
                    if(ck!=null)
                    {
                    String userId = ck[0].getValue();
                    String pId=request.getParameter("ID");
                    int pID=Integer.parseInt(pId);
                    CustomerDao customerdao=new CustomerDao();
                    customerdao.delete_order(userId, pID);;
                    
                    
							out.println("<script type=\"text/javascript\">");
			                out.println("alert('Order Deleted');");
			                out.println("location='make_delete_order.html';");
			                out.println("</script>");
						
                    }
                    else{
                    	out.println("session expired");
            			request.getRequestDispatcher("Customer_Login1.html").include(request, response);  
                    }
				
                    
    }

}
