package com.inautix.servletcontroller;


	import java.io.IOException;
	import java.io.PrintWriter;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.Cookie;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebServlet("/Logout")
	public class Customer_logout1 extends HttpServlet {
		private static final long serialVersionUID = 1L;
	       
	   
	    public Customer_logout1() {
	        super();
	       
	    }

		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			Cookie ck2=new Cookie("uname","");
			ck2.setMaxAge(0);
			response.addCookie(ck2);
			out.println(ck2.getValue());
			out.println("please enter username and password");
			request.getRequestDispatcher("Customer_Login1.html").include(request, response);  
			
		}

		
}
