package com.inautix.servletcontroller;


	import java.io.IOException;
	import java.io.PrintWriter;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.Cookie;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebServlet("/Logout")
	public class Customer_logout2 extends HttpServlet {
		private static final long serialVersionUID = 1L;
	       
	   
	    public Customer_logout2() {
	        super();
	       
	    }

		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			Cookie ck=new Cookie("uname","");
			ck.setMaxAge(0);
			response.addCookie(ck);
			out.println(ck.getValue());
			out.println("please enter username and password");
			request.getRequestDispatcher("Customer_Login2.html").include(request, response);  
			
		}

		
}
