package com.inautix.servletcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.vendor.VendorDao;




public class Add_Product_Vendor_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Add_Product_Vendor_Servlet() {
                    super();
                   
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                    throws ServletException, IOException {
                    PrintWriter out = response.getWriter();
                    Cookie ck5[]=request.getCookies();
                    int k=0;
            		if(ck5!=null)
            		{ 
            			for(int i=0;i<ck5.length;i++)
            			{
            				String name=ck5[i].getName();  
            				if(name.equals("uname"))
            				{
            					k=1;
            				}
            			}
            		}
            		if(k==1)
                    {
                    String V_phone_no=ck5[0].getValue();
                    VendorDao vendordao=new VendorDao();
                    String pname = request.getParameter("product name");
                    String price1=request.getParameter("price");
                    int price = Integer.parseInt(price1);
                    String pId1=request.getParameter("ID");
                    int pID=Integer.parseInt(pId1);
                    String vname=null;
					try {
						vname = vendordao.getVname(V_phone_no);
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
                   
                   
					
                    vendordao.put_product_details(pID, pname, vname, price);
                    
                    
							out.println("<script type=\"text/javascript\">");
			                out.println("alert('Product Added');");
			                out.println("location='add_product.html';");
			                out.println("</script>");
						
                    }
                    else{
                    	out.println("session expired");
            			request.getRequestDispatcher("Vendor_Login.html").include(request, response);  
                    }
				
                    
    }
}
