package com.inautix.admin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.inautix.order.ConnectionManager;

public class AdminDao {
	public static boolean isValid(String username,String password) throws SQLException
    {
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           
                  stmt = con.prepareStatement("select * from T_XBBNHMH_ADMINDETAILS where Admin_ID = ? AND  Password_Admin= ?");
                  stmt.setString(1, username);
                  stmt.setString(2, password);
           
           boolean isValid = false;
           ResultSet rs = null;
           
           rs = stmt.executeQuery();
                  
           while(rs.next())
           {
                  isValid = true;
           }
           return isValid;
           
    }
	
	public void delete_product_detail(int prod)
	{
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String insertQuery = "delete from T_XBBNHMH_PRODUCTDETAILS where product_id=?";
		try {
			 stmt=conn.prepareStatement(insertQuery);
			 stmt.setInt(1,prod);
			 stmt.executeUpdate();
			 
			
			 } catch (SQLException e) 
			 {e.printStackTrace();}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
    
	public void put_product_details(int p_id,String P_name,String v_name,int price)
	{
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		String insertQuery = "Insert into T_XBBNHMH_PRODUCTDETAILS(product_id,V_name,product_name,price) values(?,?,?,?)";
		try {
			 stmt=conn.prepareStatement(insertQuery);
			 stmt.setInt(1,p_id);
			 stmt.setString(2,v_name);
			 stmt.setString(3,P_name);
			 stmt.setInt(4,price);
			 stmt.executeUpdate();
			 
			
			 } catch (SQLException e) 
			 {e.printStackTrace();}	
		finally{
			try {
				
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

}
