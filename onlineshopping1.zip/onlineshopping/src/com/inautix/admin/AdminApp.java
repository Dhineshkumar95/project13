package com.inautix.admin;

import java.sql.SQLException;
import java.util.Scanner;

public class AdminApp {
	public static void main(String[] args) throws SQLException {
		System.out.println("enter admin id");
		Scanner sc = new Scanner(System.in);
		String u=sc.nextLine();
		System.out.println("enter password");
		String p=sc.nextLine();
		AdminDao adminDao=new AdminDao();
		boolean isValid = adminDao.isValid(u,p);
        if(isValid == true)
        {
        	System.out.println("Logged in successfully");
        	System.out.println("1.add product\n2.delete product\n3.exit");
        	int ch=sc.nextInt();
        	switch(ch)
        	{
        	case 1:
        	{
        		System.out.println("enter product id");
        		int pro=sc.nextInt();
        		sc.nextLine();
        		System.out.println("enter product name");
        		String pn=sc.nextLine();
        		System.out.println("enter vendor name");
        		String vn=sc.nextLine();
        		System.out.println("enter price");
        		int pric=sc.nextInt();
        		adminDao.put_product_details(pro,pn,vn,pric);
        		System.out.println("added");
        		break;
        	}
        	case 2:
        	{
        		System.out.println("enter product id to delete");
        		int prod=sc.nextInt();
        		adminDao.delete_product_detail(prod);
        		System.out.println("removed");
        		break;
        	}
        	case 3:
        		break;
        	}
        	
        }
        else
        {
               System.out.println("Wrong Password...try again");
        }

	}

	
}
