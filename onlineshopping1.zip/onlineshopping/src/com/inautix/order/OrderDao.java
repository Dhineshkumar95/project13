package com.inautix.order;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class OrderDao {
	
	public static boolean isValid(String username,String password) throws SQLException
    {
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           
                  stmt = con.prepareStatement("select * from T_XBBNHMH_ADMINDETAILS where Admin_ID = ? AND  Password_Admin= ?");
                  stmt.setString(1, username);
                  stmt.setString(2, password);
           
           boolean isValid = false;
           ResultSet rs = null;
           
           rs = stmt.executeQuery();
                  
           while(rs.next())
           {
                  isValid = true;
           }
           return isValid;
           
    }
		
	public List getOrder(String C_phone_no)
	{
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<OrderBean> Order = null;
			ResultSet resultset = null;
			String searchQuery = "SELECT *  from T_XBBNHMH_ORDERLIST where C_PHOne_NO=?";
			try {
				 stmt=conn.prepareStatement(searchQuery);
				 stmt.setString(1,C_phone_no);
				 resultset=stmt.executeQuery();
				 Order = new ArrayList<OrderBean>();
				 
				while(resultset.next()) 
				 {
					OrderBean orderBean = new OrderBean();
					
					orderBean.setC_PHONE_NO(resultset.getString(1));
					orderBean.setPRICE(resultset.getInt(4));
					orderBean.setPRODUCT_ID(resultset.getInt(2));
					orderBean.setDELIVERY_ADDRESS(resultset.getString(3));
					
					Order.add(orderBean);
				  }
				
				 } catch (SQLException e) 
				 {e.printStackTrace();}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
			}
			return Order;
	}	

	public List getOrderList()
	{
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			List<OrderBean> OrderList = null;
			ResultSet resultset = null;
			String searchQuery = "SELECT *  from T_XBBNHMH_ORDERLIST";
			try {
				 stmt=conn.prepareStatement(searchQuery);
				 
				 resultset=stmt.executeQuery();
				 OrderList = new ArrayList<OrderBean>();
				 
				while(resultset.next()) 
				 {
					OrderBean orderBean = new OrderBean();
					orderBean.setC_PHONE_NO(resultset.getString(1));
					orderBean.setPRICE(resultset.getInt(4));
					orderBean.setPRODUCT_ID(resultset.getInt(2));
					orderBean.setDELIVERY_ADDRESS(resultset.getString(3));
					OrderList.add(orderBean);
				  }
				
				 } catch (SQLException e) 
				 {e.printStackTrace();}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						e.printStackTrace();
					}
					}
			return OrderList;
			
	}	

	public static boolean isValidUser(String username,String password) throws SQLException

    {
           
           Connection con = ConnectionManager.getConnection();
           PreparedStatement stmt = null;
           
                  stmt = con.prepareStatement("select * from T_XBBNHMH_USERDETAILS where C_PHONE_NO = ? AND  password_user= ?");
                  stmt.setString(1, username);
                  stmt.setString(2, password);
           
           boolean isValid = false;
           ResultSet rs = null;
           
           rs = stmt.executeQuery();
                  
           while(rs.next())
           {
                  isValid = true;
           }
           return isValid;
           
    }

}
