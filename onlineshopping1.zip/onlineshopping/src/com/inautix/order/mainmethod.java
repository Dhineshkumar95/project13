package com.inautix.order;
import java.sql.SQLException;
import java.util.Scanner;

import com.inautix.admin.AdminApp;
import com.inautix.customer.CustomerApp;
import com.inautix.order.*;
import com.inautix.product.ProductApp;
import com.inautix.vendor.VendorApp;


public class mainmethod {
	public static void main(String[] args) throws SQLException {
		OrderApp order=new OrderApp();
		ProductApp product=new ProductApp();
		VendorApp vendor=new VendorApp();
		CustomerApp customer=new CustomerApp();
		AdminApp admin=new AdminApp();
		App2 app2=new App2();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("ONLINE SHOPPING");
		System.out.println("1.Admin\n2.Customer\n3.Vendor\n4.exit");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
		{
			System.out.println("1.add/delete product\n2.display products\n3.display orders\n4.exit");
			int choice1=sc.nextInt();
			switch(choice1)
			{
			case 1:
			{
				admin.main(args);
				break;
			}
			case 2:
			{
				product.main(args);
				break;
			}
			case 3:
			{
				app2.main(args);
				break;
			}
			case 4:
				{
					System.exit(0);
					break;
				}
			default:
			{
				System.exit(0);
				break;
			}
			}
			break;
		}
		case 2:
		{
			System.out.println("1.make/delete order\n2.display products\n3.display orders\n4.exit");
			int choice2=sc.nextInt();
			switch(choice2)
			{
			case 1:
			{
				customer.main(args);
				break;
			}
			case 2:
			{
				product.main(args);
				break;
			}
			case 3:
			{
				App1.main(args);
				break;
			}
			case 4:
				{
					System.exit(0);
				}
			default:
			{
				System.exit(0);
				break;
			}
			}
			break;
		}
		case 3:
		{
			System.out.println("1.add products\n2.display products\n3.exit");
			int choice3=sc.nextInt();
			switch(choice3)
			{
			case 1:
			{
				vendor.main(args);
				break;
			}
			case 2:
			{
				product.main(args);
				break;
			}
			case 3:
				{
					System.exit(0);
				}
			default:
			{
				System.exit(0);
				break;
			}
			}
		}
		case 4:
		{
			System.exit(0);
			break;
		}
		default:
		{
			System.exit(0);
			break;
		}
		}
		
	}
}
