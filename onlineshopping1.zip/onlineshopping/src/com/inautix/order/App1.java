package com.inautix.order;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class App1 {
	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		OrderDao orderDao = new OrderDao();
		System.out.println("enter phone number(user id)");
		String C_phone_no=sc.nextLine();
		System.out.println("enter password");
		String pw=sc.nextLine();
		boolean isValid = orderDao.isValidUser(C_phone_no,pw);
	    if(isValid == true)
	        {
	        	System.out.println("logged in successfully");
	        	List<OrderBean> Order = orderDao.getOrder(C_phone_no);
	        	Iterator<OrderBean> itr =  Order.iterator();
	        	while(itr.hasNext())
	        	{
	        			OrderBean orderBean = itr.next();
	        			System.out.println(orderBean.getC_PHONE_NO() +"\t\t" 
	        					+orderBean.getPRODUCT_ID()+"\t\t"+ orderBean.getPRICE() +"\t\t"+orderBean.getDELIVERY_ADDRESS());
	        	}
	        }
	    else System.out.println("wrong id/password");
	}
}
