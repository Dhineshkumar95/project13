package com.inautix.order;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Demo {

	public static void main(String[] args) {
		Connection con=null;
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        
        //create connection object
        
     try {
		con=DriverManager.getConnection("jdbc:derby://10.78.233.58:1527/Demo","user","pwd");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
        System.out.println("Connected");


	}

}
