package com.inautix.order;




	public class OrderBean {
		
		private int PRICE;
	    private String C_PHONE_NO;
	    private String DELIVERY_ADDRESS;
	    private int PRODUCT_ID;
	    public int getPRODUCT_ID() {
			return PRODUCT_ID;
		}
		public void setPRODUCT_ID(int pRODUCT_ID) {
			PRODUCT_ID = pRODUCT_ID;
		}
		public String getC_PHONE_NO() {
			return C_PHONE_NO;
		}
		public void setC_PHONE_NO(String c_PHONE_NO) {
			C_PHONE_NO = c_PHONE_NO;
		}
		
	    
		public int getPRICE() {
			return PRICE;
		}
		public void setPRICE(int pRICE) {
			PRICE = pRICE;
		}
		public String getDELIVERY_ADDRESS() {
			return DELIVERY_ADDRESS;
		}
		public void setDELIVERY_ADDRESS(String dELIVERY_ADDRESS) {
			DELIVERY_ADDRESS = dELIVERY_ADDRESS;
		}
		
		
	 
	    
		
}
