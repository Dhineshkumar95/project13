package com.inautix.order;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class App2 {
public static void main(String[] args) throws SQLException {
	Scanner sc = new Scanner(System.in);
	OrderDao orderDao = new OrderDao();
	 System.out.println("enter admin id");
	 String u=sc.nextLine();
	 System.out.println("enter password");
	 String p=sc.nextLine();
	 boolean flag=orderDao.isValid(u, p);
	 if(flag==true)
	 {
	 List<OrderBean> Order1 = orderDao.getOrderList();
	 Iterator<OrderBean> itr1 =  Order1.iterator();
	
	 while(itr1.hasNext())
	{
		OrderBean orderBean = itr1.next();
		System.out.println(orderBean.getC_PHONE_NO() +"\t\t" 
				+orderBean.getPRODUCT_ID()+"\t\t"+ orderBean.getPRICE() +"\t\t"+orderBean.getDELIVERY_ADDRESS());
	}
	 }
	 else System.out.println("wrong id/password");
}
}
